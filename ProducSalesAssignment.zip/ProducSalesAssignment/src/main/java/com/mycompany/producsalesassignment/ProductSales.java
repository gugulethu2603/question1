package com.mycompany.producsalesassignment;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 50324
 */
public class ProductSales implements IProduct {

    @Override
    public int TotalSales(int[][] productSales) {

        int total = 0;

        for (int row = 0; row < productSales.length; row++) {
            for (int col = 0; col < productSales[row].length; col++) {
                total += productSales[row][col];
            }
        }

        return total;
    }

    @Override
    public double AverageSales(int[][] productSales) {

        int total = 0;
        int count = 0;

        for (int row = 0; row < productSales.length; row++) {
            for (int col = 0; col < productSales[row].length; col++) {
                total += productSales[row][col];
                count++;
            }
        }

        return (double) total / count;
    }

    @Override
    public int MaxSale(int[][] productSales) {

        int max = productSales[0][0];

        for (int row = 0; row < productSales.length; row++) {
            for (int col = 0; col < productSales[row].length; col++) {

                if (productSales[row][col] > max) {
                    max = productSales[row][col];
                }
            }
        }

        return max;
    }

    @Override
    public int MinSale(int[][] productSales) {

        int min = productSales[0][0];

        for (int row = 0; row < productSales.length; row++) {
            for (int col = 0; col < productSales[row].length; col++) {

                if (productSales[row][col] < min) {
                    min = productSales[row][col];
                }
            }
        }

        return min;
    }
}
