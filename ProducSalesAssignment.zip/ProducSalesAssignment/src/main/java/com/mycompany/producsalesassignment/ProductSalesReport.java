package com.mycompany.producsalesassignment;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 50324
 */
public class ProductSalesReport {

    public static void main(String[] args) {

        int[][] sales = {
            {300, 150, 700},
            {250, 200, 600}
        };

        ProductSales ps = new ProductSales();

        int total = ps.TotalSales(sales);
        double average = ps.AverageSales(sales);
        int max = ps.MaxSale(sales);
        int min = ps.MinSale(sales);

        System.out.println("PRODUCT SALES REPORT - 2025");
        System.out.println("--------------------------------");

        System.out.println("Total Sales   : " + total);
        System.out.println("Average Sales : " + Math.round(average));
        System.out.println("Maximum Sale  : " + max);
        System.out.println("Minimum Sale  : " + min);

        System.out.println("--------------------------------");
    }
}
